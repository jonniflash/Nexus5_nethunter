# kaliphish
A musket team has rewritten the WPA2 phishing program initially produced by:

  http://technicdynamic.com/2011/12/hacking-wpa-2-key-evil-twin-no-bruteforce

  Program meant to be run in kali-linux but may run in BT5R3

We have embedded a WPA Enterprise approach.

You can download:

    kaliphish.sh
    verizon folder
    enterprise folder
    help files

A zip file kaliphish.zip with the above contents is available at:

http://www.axifile.com/en/C499791E65

When downloading axifile will assign a file named axifile.com-kaliphish.zip

Bring into view that which is hidden

MTA
